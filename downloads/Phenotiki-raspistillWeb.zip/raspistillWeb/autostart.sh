#!/bin/bash
cd /home/pi/Development/raspistillWeb
../bin/pserve development.ini
